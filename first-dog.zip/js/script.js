// The meals the dog can have
var meals = {
    steak: ['steak', 30],
    milk: ["milk", 10],
    dogFood: ["dog food", 20]
}

// The dog constructor
function Dog ( dogName ){
    this.name = 'mircea';
    this.addName = function(theName) {
        this.name = theName;
    };
    this.showName = function() {
        console.log("your dog's name is " + this.name);
    };
    this.eat = eat;
    this.saturation = 10;
};

// Eat function
function eat(meal) {
    this.saturation += meal[1];
    if (this.saturation < 100) {
        console.log(this.name + " is eating " + meal[0] + " and is " + this.saturation + "% stuffed");
    }
    else {
        console.log(this.name + " is full");
    }
}
    
// Le dog
var leDog = new Dog();





// function makeDogEat(dogName) {
//     console.log(dogName + " is eating");
// }

// var Dog = {
//     name: "guest",
//     askName: function(dogName) {
//         this.name = dogName;
//     },
//     sayName: function() {
//         console.log("Your dog's name is " + this.name)    
//     },
//     eat: function() {
//         console.log(this.name + " is eating");
//     }
    
// }